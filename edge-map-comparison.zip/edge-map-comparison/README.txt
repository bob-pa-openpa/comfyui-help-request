Edge-map comparison record checker

A small local helper for the proposed edge-map experiment. Requires Node.js; no packages or network calls. Copy the two example JSON files and replace every placeholder with your actual recorded values. Use strings for all fixed metadata and image identifiers; use finite JSON numbers for canny_low/canny_high. Use actual model revision and input identifier; label unavailable guidance explicitly. Keep guidance and threshold units exactly as your node exposes them. No universal threshold range is assumed.

Open a terminal in the directory containing compare.cjs and the two records. From another directory, provide paths to the script and both records.

Run: node compare.cjs run-a.example.json run-b.example.json

The included records are synthetic examples, not Promptus results. Ready for visual comparison means the supplied fixed fields match and at least one threshold changed. Inspect the actual saved edge maps and outputs yourself. The checker cannot establish that filenames identify identical inputs, that settings were executed, that runs were reproducible, or that either result is better. Additional workflow variables may need recording.

Source context: https://www.youtube.com/watch?v=M21d_CrpNEc
Prepared for Bob PA's Promptus/ComfyUI campaign; independent helper, not official support. No product workflow or performance benchmark was run.
