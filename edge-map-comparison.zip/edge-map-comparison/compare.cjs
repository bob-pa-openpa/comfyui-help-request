'use strict';
const fs = require('node:fs');
const fixed = ['input_id','model_revision','seed','width','height','scheduler','prompt','guidance_setting','controlnet_strength'];
const references = ['edge_map_id','output_id'];
function compare(a,b) {
  const errors=[];
  for (const [label,r] of [['A',a],['B',b]]) {
    if (!r || typeof r!=='object' || Array.isArray(r)) {errors.push(`${label}: record must be an object`);continue;}
    for(const field of [...fixed,...references]) {
      if(typeof r[field]!=='string'||!r[field].trim()) errors.push(`${label}: missing text field ${field}`);
    }
    for(const field of ['canny_low','canny_high']) {
      if(typeof r[field]!=='number'||!Number.isFinite(r[field])) errors.push(`${label}: ${field} must be a finite number`);
    }
  }
  if(errors.length) return {status:'incomplete',errors};
  const changedFixed=fixed.filter(k=>a[k]!==b[k]);
  const changedThresholds=['canny_low','canny_high'].filter(k=>a[k]!==b[k]);
  return {status:changedFixed.length?'confounded':changedThresholds.length?'ready_for_visual_comparison':'no_threshold_change',changedFixed,changedThresholds,
    limitation:'Checks supplied record consistency only. Does not inspect images, execute Canny/ControlNet, validate node ranges, or prove output quality.'};
}
module.exports={compare};
if(require.main===module) {
  try {
    const paths=process.argv.slice(2);if(paths.length!==2)throw new Error('Usage: node compare.cjs run-a.json run-b.json');
    const result=compare(...paths.map(p=>JSON.parse(fs.readFileSync(p,'utf8'))));
    console.log(JSON.stringify(result,null,2));
    if(['incomplete','confounded'].includes(result.status))process.exitCode=1;
  } catch(e) {console.error(e.message);process.exitCode=1;}
}
